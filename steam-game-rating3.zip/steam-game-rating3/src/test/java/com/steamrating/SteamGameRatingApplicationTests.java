package com.steamrating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SteamGameRatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
