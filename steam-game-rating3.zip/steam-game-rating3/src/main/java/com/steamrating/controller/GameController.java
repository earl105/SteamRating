// src/main/java/com/steamrating/controller/GameController.java
package com.steamrating.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.steamrating.model.Game;
import com.steamrating.repository.GameRepository;
import com.steamrating.service.SteamService;

@Controller
public class GameController {
    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private SteamService steamService;

    @GetMapping("/")
    public String showHome() {
        return "home";
    }

    @PostMapping("/fetch-games")
    public String fetchGames(@RequestParam String steamUrl, Model model) {
        try {
            String steam64id = this.steamService.getSteam64ID(steamUrl);
            List<String> games = this.steamService.getOwnedGames(steam64id);
            Collections.shuffle(games);

            // Store games in database
            games.stream().limit(10).forEach(gameName -> {
                Game game = new Game();
                game.setName(gameName);
                this.gameRepository.save(game);
            });

            return "redirect:/rate/user1/0";
        } catch (Exception e) {
            model.addAttribute("error", "Error fetching games: " + e.getMessage());
            return "home";
        }
    }

    @GetMapping("/rate/user{userNum}/{gameIndex}")
    public String showRating(@PathVariable int userNum, @PathVariable int gameIndex,
            Model model) {
        List<Game> games = this.gameRepository.findAll();

        if (gameIndex >= games.size()) {
            if (userNum == 1) {
                return "redirect:/rate/user2/0";
            } else {
                return "redirect:/results";
            }
        }

        model.addAttribute("game", games.get(gameIndex));
        model.addAttribute("userNum", userNum);
        model.addAttribute("gameIndex", gameIndex);
        return "rate";
    }

    @PostMapping("/rate/submit")
    public String submitRating(@RequestParam Long gameId, @RequestParam int userNum,
            @RequestParam int playRating, @RequestParam int watchRating,
            @RequestParam int gameIndex) {
        Game game = this.gameRepository.findById(gameId).orElseThrow();

        if (userNum == 1) {
            game.setUser1PlayRating(playRating);
            game.setUser1WatchRating(watchRating);
        } else {
            game.setUser2PlayRating(playRating);
            game.setUser2WatchRating(watchRating);
        }

        this.gameRepository.save(game);
        return "redirect:/rate/user" + userNum + "/" + (gameIndex + 1);
    }

    @GetMapping("/results")
    public String showResults(Model model) {
        List<Game> games = this.gameRepository.findAll();
        model.addAttribute("games", games);
        return "results";
    }
}
