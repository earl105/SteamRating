// src/main/java/com/steamrating/repository/GameRepository.java
package com.steamrating.repository;

import com.steamrating.model.Game;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameRepository extends JpaRepository<Game, Long> {
}