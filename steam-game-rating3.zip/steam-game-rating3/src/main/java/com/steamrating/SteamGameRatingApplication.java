package com.steamrating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan("com.steamrating.model") // Add this line
public class SteamGameRatingApplication {
    public static void main(String[] args) {
        SpringApplication.run(SteamGameRatingApplication.class, args);
    }
}
