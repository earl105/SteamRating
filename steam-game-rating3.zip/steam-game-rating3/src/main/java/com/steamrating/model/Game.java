// src/main/java/com/steamrating/model/Game.java
package com.steamrating.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Integer appId;
    private Integer user1PlayRating;
    private Integer user1WatchRating;
    private Integer user2PlayRating;
    private Integer user2WatchRating;

    // Getters and setters
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAppId() {
        return this.appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Integer getUser1PlayRating() {
        return this.user1PlayRating;
    }

    public void setUser1PlayRating(Integer rating) {
        this.user1PlayRating = rating;
    }

    public Integer getUser1WatchRating() {
        return this.user1WatchRating;
    }

    public void setUser1WatchRating(Integer rating) {
        this.user1WatchRating = rating;
    }

    public Integer getUser2PlayRating() {
        return this.user2PlayRating;
    }

    public void setUser2PlayRating(Integer rating) {
        this.user2PlayRating = rating;
    }

    public Integer getUser2WatchRating() {
        return this.user2WatchRating;
    }

    public void setUser2WatchRating(Integer rating) {
        this.user2WatchRating = rating;
    }
}
