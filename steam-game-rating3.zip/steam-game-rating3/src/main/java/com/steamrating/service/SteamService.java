// src/main/java/com/steamrating/service/SteamService.java
package com.steamrating.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SteamService {
    @Value("${steam.api.key}")
    private String apiKey;

    public String getSteam64ID(String steamURL) throws Exception {
        if (steamURL.contains("/id/")) {
            String customID = steamURL.split("/id/")[1].split("/")[0];
            return this.resolveVanityURL(customID);
        } else if (steamURL.contains("/profiles/")) {
            return steamURL.split("/profiles/")[1].split("/")[0];
        }
        throw new Exception("Invalid Steam URL format");
    }

    private String resolveVanityURL(String customID) throws Exception {
        String apiURL = String.format(
                "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1/?key=%s&vanityurl=%s",
                this.apiKey, customID);

        JSONObject response = new JSONObject(this.makeApiCall(apiURL));
        if (response.getJSONObject("response").getInt("success") == 1) {
            return response.getJSONObject("response").getString("steamid");
        }
        throw new Exception("Unable to resolve vanity URL");
    }

    public List<String> getOwnedGames(String steam64id) throws Exception {
        String urlString = String.format(
                "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=%s&steamid=%s&format=json",
                this.apiKey, steam64id);

        JSONObject response = new JSONObject(this.makeApiCall(urlString));
        List<String> games = new ArrayList<>();

        if (response.getJSONObject("response").has("games")) {
            response.getJSONObject("response").getJSONArray("games").forEach(game -> {
                JSONObject gameObj = (JSONObject) game;
                String gameName = this.getGameName(gameObj.getInt("appid"));
                if (!gameName.equals("Game not found")
                        && !gameName.equals("Error fetching game name")) {
                    games.add(gameName);
                }
            });
        }
        return games;
    }

    private String getGameName(int appid) {
        try {
            Thread.sleep(1000); // Rate limiting
            String urlString = "https://store.steampowered.com/api/appdetails?appids="
                    + appid;
            JSONObject response = new JSONObject(this.makeApiCall(urlString));

            if (response.getJSONObject(String.valueOf(appid)).getBoolean("success")) {
                return response.getJSONObject(String.valueOf(appid)).getJSONObject("data")
                        .getString("name");
            }
            return "Game not found";
        } catch (Exception e) {
            return "Error fetching game name";
        }
    }

    private String makeApiCall(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line);
            }
        }
        return content.toString();
    }
}
